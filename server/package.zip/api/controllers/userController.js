// File: controllers/userController.js
// Contains logic for managing executive users.
const bcrypt = require("bcryptjs");
const { getDB } = require("../../config/db.js");

// @desc    Get all users
// @route   GET /api/users
// @access  Private/Admin
const getUsers = async (req, res) => {
  try {
    const db = getDB();
    const [users] = await db.query(
      "SELECT id, email, role, regionId, districtId, branchId FROM users ORDER BY email"
    );
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: "Server error fetching users." });
  }
};

// @desc    Create a new user
// @route   POST /api/users
// @access  Private/Admin
const createUser = async (req, res) => {
  const { email, password, role, regionId, districtId, branchId } = req.body;
  if (!email || !password || !role)
    return res
      .status(400)
      .json({ message: "Please provide email, password, and role" });

  try {
    const db = getDB();
    const [existingUsers] = await db.query(
      "SELECT * FROM users WHERE email = ?",
      [email]
    );
    if (existingUsers.length > 0)
      return res
        .status(400)
        .json({ message: "User with this email already exists" });

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const [result] = await db.query(
      "INSERT INTO users (email, password, role, regionId, districtId, branchId) VALUES (?, ?, ?, ?, ?, ?)",
      [
        email,
        hashedPassword,
        role,
        regionId || null,
        districtId || null,
        branchId || null,
      ]
    );

    if (result.affectedRows === 1) {
      res.status(201).json({ id: result.insertId, email, role });
    } else {
      res.status(400).json({ message: "Invalid user data" });
    }
  } catch (error) {
    res.status(500).json({ message: "Server error creating user" });
  }
};

// @desc    Update a user
// @route   PUT /api/users/:id
// @access  Private/Admin
const updateUser = async (req, res) => {
  const { email, role, regionId, districtId, branchId } = req.body;
  if (!email || !role)
    return res.status(400).json({ message: "Email and role are required" });

  try {
    const db = getDB();
    const [result] = await db.query(
      "UPDATE users SET email = ?, role = ?, regionId = ?, districtId = ?, branchId = ? WHERE id = ?",
      [
        email,
        role,
        regionId || null,
        districtId || null,
        branchId || null,
        req.params.id,
      ]
    );

    if (result.affectedRows > 0) {
      res.json({ message: "User updated successfully" });
    } else {
      res.status(404).json({ message: "User not found" });
    }
  } catch (error) {
    res.status(500).json({ message: "Server error updating user" });
  }
};

// @desc    Delete a user
// @route   DELETE /api/users/:id
// @access  Private/Admin
const deleteUser = async (req, res) => {
  try {
    const db = getDB();
    const [result] = await db.query("DELETE FROM users WHERE id = ?", [
      req.params.id,
    ]);

    if (result.affectedRows > 0) {
      res.json({ message: "User deleted successfully" });
    } else {
      res.status(404).json({ message: "User not found" });
    }
  } catch (error) {
    res.status(500).json({ message: "Server error deleting user" });
  }
};

module.exports = { getUsers, createUser, updateUser, deleteUser };
